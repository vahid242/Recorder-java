// wap Assignment1 Q1
/*
    @author Vahid Ghaedsharaf
    @Version1
    date : 15th Sept 2019
 */
public class Q1 {
    public static void main(String[] ar) {
//    display a table of entered data
        System.out.println("A   b   pow(A,b)");
        System.out.println("1   2   1");
        System.out.println("2   3   8");
        System.out.println("3   4   81");
    }
}