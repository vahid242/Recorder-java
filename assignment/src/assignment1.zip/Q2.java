// wap Assignment1 Q2
/*
    @author Vahid Ghaedsharaf
    @Version1
    date : 15th Sept 2019
 */
public class Q2 {
    public static void main(String[] ar){
//        display information about myself
        System.out.println("First Name: Vahid");
        System.out.println("Last Name: Ghaedsharaf");
        System.out.println("languages known: HTML, Javascript, Java");
        System.out.println("Favorite Field of Study:Computer Programing");
        System.out.println("Hobbies: jogging, fishing");
        System.out.println("Favorite Color: green");
        System.out.println("Favorite Pet: My favorite pet is Cat." +
                " I have a persian cat. She's name is lili. she is so cute and she has long hair");
    }
}
